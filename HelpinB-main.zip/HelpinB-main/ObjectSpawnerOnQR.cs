using System.Collections.Generic;
using UnityEngine;
using PassthroughCameraSamples;

#if ZXING_ENABLED
public class ObjectSpawnerOnQR : MonoBehaviour
{
    // A helper class to create a mapping in the Inspector between
    // the text content of a QR code and the prefab to spawn.
    [System.Serializable]
    public class QRCodePrefabMapping
    {
        public string QRCodeText;
        public GameObject PrefabToSpawn;
    }

    [Tooltip("Populate this array in inspector with QRCodeMapping scriptable objects.")]
    [SerializeField]
    private QRCodeMapping[] qrCodeMappings;

    // A dictionary for lookups of prefabs by their QR code text.
    private Dictionary<string, GameObject> _prefabDictionary = new Dictionary<string, GameObject>();

    // A dictionary to track the objects already spawned for each QR code text,
    // preventing duplicate spawning.
    private Dictionary<string, GameObject> _spawnedObjects = new Dictionary<string, GameObject>();

    void Awake()
    {
		/* Allie - We're essentially doing the same as what was here before,
			for each item in the qrCodeMappings array, create an associated dictionary entry.

			Normally, using a flat array as a lookup like this would be considered bad coding practice. 
			Unity is an enabler though, the inspector negates the need to manually code the array (it does the bad practice FOR US! Hooray!)
			and as we're using some nice, speedy dictionaries at runtime and only really use this array here in this function and in the inspector
			(which, it should be noted, is actually a great visual tool in this context) there should be virtually no performacne impact past initial launch.
			
			Should this array get unwieldy, the simple fix would be to simply iterate over the project itself 
			and populate an array from found ScriptableObjects. We're not doing that here cause you're not paying me ;) */
		
        foreach (QRCodeMapping mapping in qrCodeMappings)
        {
            if (!string.IsNullOrEmpty(mapping.qrCodeString) && !_prefabDictionary.ContainsKey(mapping.qrCodeString))
            {
                _prefabDictionary.Add(mapping.qrCodeString, mapping.associatedPrefab);
            }
        }
    }

    // Update the parameter type to match the QrCodeResult from the QuestCameraKit sample
    public void OnQRCodeDetected(QrCodeResult qrCode)
    {
        string decodedText = qrCode.text;

        if (_prefabDictionary.TryGetValue(decodedText, out GameObject prefabToSpawn))
        {
            if (_spawnedObjects.TryGetValue(decodedText, out GameObject spawnedObject))
            {
                // Calculate position and rotation from QR code corners
                Vector3 position = Vector3.zero;
                foreach (var corner in qrCode.corners)
                {
                    position += corner;
                }
                position /= qrCode.corners.Length;

                // Calculate rotation from QR code corners
                Vector3 forward = Vector3.Cross(
                    qrCode.corners[1] - qrCode.corners[0],
                    qrCode.corners[3] - qrCode.corners[0]
                ).normalized;

                Vector3 up = (qrCode.corners[1] - qrCode.corners[0]).normalized;

                spawnedObject.transform.SetPositionAndRotation(
                    position,
                    Quaternion.LookRotation(forward, up)
                );
            }
            else
            {
                // If this is a new QR code and hasn't spawned an object yet, instantiate it.
                Debug.Log($"Found new QR Code with text: '{decodedText}'. Spawning object.");

                Vector3 position = Vector3.zero;
                foreach (var corner in qrCode.corners)
                {
                    position += corner;
                }
                position /= qrCode.corners.Length;

                Vector3 forward = Vector3.Cross(
                    qrCode.corners[1] - qrCode.corners[0],
                    qrCode.corners[3] - qrCode.corners[0]
                ).normalized;

                Vector3 up = (qrCode.corners[1] - qrCode.corners[0]).normalized;

                GameObject newObject = Instantiate(
                    prefabToSpawn,
                    position,
                    Quaternion.LookRotation(forward, up)
                );

                // Add the newly spawned object to tracking dictionary.
                _spawnedObjects.Add(decodedText, newObject);
            }
        }
    }
}
#endif
